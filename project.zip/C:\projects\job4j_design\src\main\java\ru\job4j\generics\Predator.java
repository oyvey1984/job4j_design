package ru.job4j.generics;

public class Predator extends Animal {
    public Predator(String species, boolean canFly, int numberOfTeeth) {
        super(species, canFly, numberOfTeeth);
    }
}