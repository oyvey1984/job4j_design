package ru.job4j.generics;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public class Programmer extends Person {
    public Programmer(String name, int age, Date birthday) {
        super(name, age, birthday);
    }
}
