package ru.job4j.generics;

public class Tiger extends Predator {
    public Tiger(String species, boolean canFly, int numberOfTeeth) {
        super(species, canFly, numberOfTeeth);
    }
}